package com.example.chethangarapati.parkinglot;

class LoginService {

    public boolean login(String username, String password) {
        return "james".equals(username) && "bond".equals(password);
    }
}
